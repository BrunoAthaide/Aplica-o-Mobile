package com.example.impostoderenda;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText rendaBrutaMensal, dependentes, deducoes;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rendaBrutaMensal = findViewById(R.id.rendaBrutaMensal);
        dependentes = findViewById(R.id.dependentes);
        deducoes = findViewById(R.id.deducoes);
        Button calcularButton = findViewById(R.id.calcularButton);
        result = findViewById(R.id.result);

        calcularButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularIR();
            }
        });
    }

    private void calcularIR() {
        double rendaMensal = Double.parseDouble(rendaBrutaMensal.getText().toString());
        int numDependentes = Integer.parseInt(dependentes.getText().toString());
        double totalDeducoes = Double.parseDouble(deducoes.getText().toString());

        double rendaBrutaAnual = rendaMensal * 12;
        double baseCalculo = rendaBrutaAnual - (7200 + (300 * numDependentes)) - totalDeducoes;
        double imposto = calcularImposto(baseCalculo);

        String resultado = "Renda Bruta Anual: " + rendaBrutaAnual +
                "\nBase de Cálculo: " + baseCalculo +
                "\nImposto Devido: " + imposto;
        result.setText(resultado);
    }

    private double calcularImposto(double baseCalculo) {
        if (baseCalculo <= 18000) {
            return 0;
        } else if (baseCalculo <= 27000) {
            return (baseCalculo - 18000) * 0.15;
        } else {
            double excesso = baseCalculo - 27000;
            return 1350 + (excesso * 0.275);
        }
    }
}